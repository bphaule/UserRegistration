package controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import edu.dmacc.spring.userregistration.User;

public class UserDao {
		
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("UserRegistration");
		
		public void insertUser(User userToAdd){
			EntityManager em = emfactory.createEntityManager();
			em.getTransaction().begin();
			em.persist(userToAdd);
			em.getTransaction().commit();
			em.close();
			emfactory.close();
				
		}

	}



