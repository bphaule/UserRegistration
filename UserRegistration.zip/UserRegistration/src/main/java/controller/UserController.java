package controller;

import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import edu.dmacc.spring.userregistration.User;

@Controller
public class UserController {
	private static final String[ ] countries = { "France", "United States", "Germany", "England" };
    
	@RequestMapping(value = "/form")
	public ModelAndView user( ){
		ModelAndView modelAndView = new ModelAndView( );
		
		modelAndView.setViewName("userForm");
		modelAndView.addObject("user", new User());
		modelAndView.addObject("countries", countries);
		
		return modelAndView;
	}
	@RequestMapping(value = "/result")
	public ModelAndView processUser1(User user){
		System.out.println("In processUser");
		ModelAndView modelAndView = new ModelAndView();
		System.out.println("Value in getName"+ user.getName());
		modelAndView.setViewName("userResult");
		modelAndView.addObject("u", user);
		return modelAndView;
	}
	
	@Bean(autowire = "")
	public UserDao dao(){
		UserDao bean = new UserDao();
		return bean;
	}
	
	@RequestMapping(value = "/result")
	public ModelAndView processUser(User user, UserDao dao){
		ModelAndView modelAndView = new ModelAndView();
		dao.insertUser(user);
		modelAndView.setViewName("userResult");
		modelAndView.addObject("u", user);
		return modelAndView;
}
}
